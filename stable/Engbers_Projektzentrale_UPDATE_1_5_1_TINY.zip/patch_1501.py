from pathlib import Path
import ast
import datetime
import py_compile
import shutil

APP = Path(__file__).resolve().parent / 'app.py'
VERSION_OLD = '1.5.0'
VERSION_NEW = '1.5.1'
MARKER = 'PZ_PROJECT_EXPLORER_ASYNC_V1501'


def _compile_text(text, name):
    p = APP.with_name(name)
    try:
        p.write_text(text, encoding='utf-8')
        py_compile.compile(str(p), doraise=True)
    finally:
        try:
            p.unlink()
        except Exception:
            pass


def _method_span(source, method_name):
    tree = ast.parse(source)
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef) and node.name == 'App':
            for child in node.body:
                if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)) and child.name == method_name:
                    lines = source.splitlines(keepends=True)
                    start = sum(len(x) for x in lines[:child.lineno-1])
                    end = sum(len(x) for x in lines[:child.end_lineno])
                    return start, end
    raise RuntimeError(f'1.5.1: Methode {method_name} wurde nicht gefunden.')


def _replace_method(source, method_name, block):
    start, end = _method_span(source, method_name)
    return source[:start] + block.rstrip() + '\n\n' + source[end:]


PROJECT_EXPLORER_METHOD = r'''    def show_project_explorer(self):
        # PZ_PROJECT_EXPLORER_ASYNC_V1501
        # Ordner werden nur eine Ebene tief und in einem Worker gelesen. Tk bleibt dadurch responsiv.
        self.clear(); r=self.project_row(); sources=self._project_sources()
        self.titleblock(self.content,'Projekt-Explorer',f"{r['number']} · {r['title']} · echte Ordnerstruktur, Originaldateien")
        self.program_starter_bar(self.content)
        toolbar=tk.Frame(self.content,bg=BG); toolbar.pack(fill='x',pady=(0,10))
        tk.Button(toolbar,text='+ PROJEKTORDNER VERKNÜPFEN',command=self._link_project_source,bg=ACCENT,fg='white',bd=0,padx=12,pady=7).pack(side='left')
        tk.Label(toolbar,text=f"{len(sources)} Speicherort{'e' if len(sources)!=1 else ''}",bg=BG,fg=MUTED).pack(side='left',padx=(10,16))
        search_var=tk.StringVar()
        tk.Label(toolbar,text='Suche:',bg=BG,fg=MUTED).pack(side='left')
        search_entry=tk.Entry(toolbar,textvariable=search_var,width=28); search_entry.pack(side='left',padx=(5,6),ipady=4)
        load_info=tk.Label(toolbar,text='',bg=BG,fg=MUTED,font=('Segoe UI',8)); load_info.pack(side='left',padx=(8,0))

        pan,body=self.panel(self.content,'Projektakte · Explorer'); pan.pack(fill='both',expand=True)
        split=tk.PanedWindow(body,orient='horizontal',bg=PANEL,sashwidth=5,bd=0); split.pack(fill='both',expand=True)
        left=tk.Frame(split,bg=PANEL); right=tk.Frame(split,bg=PANEL,width=350)
        split.add(left,stretch='always'); split.add(right,minsize=320)
        cols=('Typ','Geändert','Größe','Bereich','Pfad')
        tr=ttk.Treeview(left,columns=cols,show='tree headings',height=22)
        tr.heading('#0',text='Ordner / Datei'); tr.column('#0',width=390,minwidth=240,stretch=True,anchor='w')
        for c,wid in (('Typ',85),('Geändert',145),('Größe',90),('Bereich',155),('Pfad',410)):
            tr.heading(c,text=c); tr.column(c,width=wid,minwidth=70,stretch=(c=='Pfad'),anchor='w')
        sy=ttk.Scrollbar(left,orient='vertical',command=tr.yview); sx=ttk.Scrollbar(left,orient='horizontal',command=tr.xview)
        tr.configure(yscrollcommand=sy.set,xscrollcommand=sx.set)
        tr.grid(row=0,column=0,sticky='nsew'); sy.grid(row=0,column=1,sticky='ns'); sx.grid(row=1,column=0,sticky='ew')
        left.grid_rowconfigure(0,weight=1); left.grid_columnconfigure(0,weight=1)
        pathmap={}; rootmap={}; sourcemap={}; loaded=set(); loading=set(); dummy='__PZ_DUMMY__'; generation=[0]

        # 1.5.1: manuelle Zuordnungen EINMAL laden, statt bei jeder Explorer-Zeile die DB erneut abzufragen.
        manual_rules=[]
        try:
            con=db(); rows=con.execute('SELECT rel_path,is_folder,category FROM file_assignments WHERE project_id=?',(self.project_id,)).fetchall(); con.close()
            for rr in rows:
                manual_rules.append((str(rr['rel_path']).replace('\\','/').rstrip('/'),bool(rr['is_folder']),rr['category']))
        except Exception:
            manual_rules=[]

        def effective_fast(rel_path):
            rel=str(rel_path).replace('\\','/').rstrip('/')
            exact=None; inherited=None; best=-1
            for rr,is_folder,category in manual_rules:
                if rel==rr: exact=(category,'manuell'); break
                if is_folder and rr and rel.startswith(rr+'/') and len(rr)>best:
                    inherited=(category,'Ordnerregel'); best=len(rr)
            if exact:return exact
            if inherited:return inherited
            try:
                cat,conf=self.classify_project_file(rel_path); return cat,'automatisch · '+conf
            except Exception:return '—','—'

        def fmt_changed_ts(ts):
            try:return datetime.datetime.fromtimestamp(ts).strftime('%d.%m.%Y %H:%M') if ts else '—'
            except Exception:return '—'
        def fmt_size_bytes(size,is_dir):
            if is_dir:return '—'
            try:return self.human_size(size)
            except Exception:return '—'

        def selected(event=None):
            iid=''
            if event is not None:
                try:iid=tr.identify_row(event.y)
                except Exception:iid=''
            if not iid:
                s=tr.selection(); iid=s[0] if s else ''
            if iid:
                try:tr.selection_set(iid); tr.focus(iid)
                except Exception:pass
            return pathmap.get(iid),rootmap.get(iid),iid

        def insert_child(parent,root,info,src):
            pp=Path(info['path']); is_dir=bool(info['is_dir'])
            try:rel=pp.relative_to(root)
            except Exception:rel=Path(pp.name)
            try:cat,_=effective_fast(rel)
            except Exception:cat='—'
            typ='Ordner' if is_dir else (pp.suffix.upper().lstrip('.') or 'Datei')
            iid=tr.insert(parent,'end',text=pp.name,values=(typ,fmt_changed_ts(info.get('mtime',0)),fmt_size_bytes(info.get('size',0),is_dir),cat,str(rel)),open=False)
            pathmap[iid]=pp; rootmap[iid]=root
            if src is not None:sourcemap[iid]=src
            # Keine zusätzliche Dateisystem-Abfrage nur für das Dreieck: Ordner werden wirklich erst beim Öffnen gelesen.
            if is_dir:tr.insert(iid,'end',text=dummy,values=('','','','',''))
            return iid

        def apply_loaded(iid,token,items,error_text=''):
            if token!=generation[0]:return
            try:
                if not tr.winfo_exists():return
            except Exception:return
            loading.discard(iid)
            try:
                for child in tr.get_children(iid):
                    if tr.item(child,'text') in (dummy,'Wird geladen …','Ordner konnte nicht gelesen werden'):
                        tr.delete(child)
            except Exception:return
            if error_text:
                try:tr.insert(iid,'end',text='Ordner konnte nicht gelesen werden',values=('Hinweis','—','—','—',error_text))
                except Exception:pass
                loaded.add(iid); load_info.configure(text=''); return
            root=rootmap.get(iid); src=sourcemap.get(iid)
            for info in items:
                try:insert_child(iid,root,info,src)
                except Exception:pass
            loaded.add(iid)
            try:load_info.configure(text='')
            except Exception:pass

        def ensure_loaded(iid):
            if not iid or iid in loaded or iid in loading:return
            pp=pathmap.get(iid); root=rootmap.get(iid)
            if pp is None or root is None:
                loaded.add(iid); return
            try:
                if not pp.is_dir():loaded.add(iid); return
            except Exception:
                loaded.add(iid); return
            loading.add(iid); token=generation[0]
            try:
                kids=tr.get_children(iid)
                for child in kids:
                    if tr.item(child,'text')==dummy:tr.item(child,text='Wird geladen …')
                load_info.configure(text='Ordner wird geladen …')
            except Exception:pass

            def worker():
                items=[]; error_text=''
                try:
                    import os as _os
                    with _os.scandir(str(pp)) as it:
                        for entry in it:
                            try:is_dir=entry.is_dir(follow_symlinks=False)
                            except Exception:
                                try:is_dir=Path(entry.path).is_dir()
                                except Exception:is_dir=False
                            try:st=entry.stat(follow_symlinks=False); mt=st.st_mtime; sz=st.st_size
                            except Exception:mt=0; sz=0
                            items.append({'path':entry.path,'name':entry.name,'is_dir':is_dir,'mtime':mt,'size':sz})
                    items.sort(key=lambda x:(not x['is_dir'],str(x['name']).casefold()))
                except Exception as exc:
                    error_text=str(exc)
                try:self.after(0,lambda:apply_loaded(iid,token,items,error_text))
                except Exception:pass
            try:
                import threading
                threading.Thread(target=worker,name='PZ-Explorer-Load',daemon=True).start()
            except Exception:
                worker()

        def add_source(src,open_root=False):
            root=Path(src['path']); label=f"{src['kind']}: {src['label']}"
            try:mt=root.stat().st_mtime if root.exists() else 0
            except Exception:mt=0
            iid=tr.insert('','end',text=label,values=('Speicherort',fmt_changed_ts(mt),'—','Projekt',str(root)),open=open_root)
            pathmap[iid]=root; rootmap[iid]=root; sourcemap[iid]=src
            if root.exists():tr.insert(iid,'end',text=dummy,values=('','','','',''))
            else:tr.insert(iid,'end',text='Ordner nicht gefunden',values=('Hinweis','—','—','—',str(root)))
            if open_root and root.exists():ensure_loaded(iid)
            return iid

        def render_normal():
            generation[0]+=1; loaded.clear(); loading.clear()
            for iid in tr.get_children(''):tr.delete(iid)
            pathmap.clear(); rootmap.clear(); sourcemap.clear()
            for idx,src in enumerate(sources):add_source(src,idx==0)

        # Suche bleibt auf 600 Treffer begrenzt; sie wird erst nach kurzer Tipp-Pause ausgelöst.
        search_after=[None]
        def render_search_now():
            q=search_var.get().strip().casefold()
            if not q:render_normal(); return
            generation[0]+=1; token=generation[0]; loaded.clear(); loading.clear()
            for iid in tr.get_children(''):tr.delete(iid)
            pathmap.clear(); rootmap.clear(); sourcemap.clear()
            load_info.configure(text='Projekt wird durchsucht …')

            def worker():
                found=[]; total=0
                for src in sources:
                    root=Path(src['path'])
                    if not root.exists():continue
                    group=[]
                    try:
                        for base,dirs,files in os.walk(str(root)):
                            # Reparse-/Symlink-Schleifen vermeiden.
                            dirs[:]=[d for d in dirs if not Path(base,d).is_symlink()]
                            for name,is_dir in [(d,True) for d in dirs]+[(f,False) for f in files]:
                                if total>=600:break
                                pp=Path(base)/name
                                try:rel=pp.relative_to(root)
                                except Exception:rel=Path(name)
                                if q not in (name+' '+str(rel)).casefold():continue
                                try:st=pp.stat(); mt=st.st_mtime; sz=st.st_size
                                except Exception:mt=0; sz=0
                                group.append({'path':str(pp),'name':name,'is_dir':is_dir,'mtime':mt,'size':sz}); total+=1
                            if total>=600:break
                    except Exception:pass
                    if group:found.append((src,group))
                    if total>=600:break

                def apply():
                    if token!=generation[0]:return
                    try:
                        for src,items in found:
                            root=Path(src['path']); label=f"{src['kind']}: {src['label']}"
                            parent=tr.insert('','end',text=label,values=('Speicherort','—','—','Projekt',str(root)),open=True)
                            pathmap[parent]=root; rootmap[parent]=root; sourcemap[parent]=src; loaded.add(parent)
                            items.sort(key=lambda x:(not x['is_dir'],str(x['path']).casefold()))
                            for info in items:insert_child(parent,root,info,src)
                        load_info.configure(text=(f'{total} Treffer' if total<600 else '600 Treffer · Suche begrenzt'))
                    except Exception:pass
                try:self.after(0,apply)
                except Exception:pass
            try:
                import threading
                threading.Thread(target=worker,name='PZ-Explorer-Search',daemon=True).start()
            except Exception:worker()

        def render_search(*_):
            try:
                if search_after[0] is not None:self.after_cancel(search_after[0])
            except Exception:pass
            try:search_after[0]=self.after(250,render_search_now)
            except Exception:render_search_now()

        tk.Label(right,text='DATEI / ORDNER',bg=PANEL,fg=INK,font=('Segoe UI Semibold',9)).pack(anchor='w',padx=12,pady=(0,8))
        detail=tk.Text(right,height=13,wrap='word',font=('Segoe UI',9),bg='#fbfaf6',fg=INK,bd=1,relief='solid'); detail.pack(fill='both',expand=True,padx=12)
        btns=tk.Frame(right,bg=PANEL); btns.pack(fill='x',padx=12,pady=8)
        assign_btn=tk.Button(btns,text='FACHLICH ZUORDNEN',bg=ACCENT,fg='white',bd=0,padx=10,pady=7); assign_btn.pack(side='left')
        open_btn=tk.Button(btns,text='ÖFFNEN',bg=DARK,fg='white',bd=0,padx=10,pady=7); open_btn.pack(side='left',padx=6)
        explorer_btn=tk.Button(btns,text='EXPLORER',bg='#e7e4dc',fg=INK,bd=0,padx=10,pady=7); explorer_btn.pack(side='left')
        unlink_btn=tk.Button(right,text='VERKNÜPFUNG DIESES SPEICHERORTS LÖSEN',bg='#e7e4dc',fg=INK,bd=0,padx=12,pady=7)
        extra=tk.Frame(right,bg=PANEL); extra.pack(fill='x',padx=12,pady=(0,8))
        copy_btn=tk.Button(extra,text='PFAD KOPIEREN',bg='#e7e4dc',fg=INK,bd=0,padx=9,pady=6); copy_btn.pack(side='left')

        def refresh_detail(_evt=None):
            pp,root,iid=selected(); detail.configure(state='normal'); detail.delete('1.0','end'); unlink_btn.pack_forget()
            if not pp:detail.configure(state='disabled'); return
            try:rel=pp.relative_to(root)
            except Exception:rel=Path('.')
            try:cat,src=effective_fast(rel) if rel!=Path('.') else ('Projekt','Speicherort')
            except Exception:cat,src='—','—'
            try:mt=pp.stat().st_mtime; changed=fmt_changed_ts(mt)
            except Exception:changed='—'
            try:size=fmt_size_bytes(pp.stat().st_size,pp.is_dir())
            except Exception:size='—'
            detail.insert('1.0',f"Name: {pp.name}\nTyp: {'Ordner' if pp.is_dir() else (pp.suffix.upper() or 'Datei')}\n\nFachbereich: {cat}\nZuordnung: {src}\n\nGeändert: {changed}\nGröße: {size}\n\nRelativer Pfad:\n{rel}\n\nOriginalpfad:\n{pp}")
            detail.configure(state='disabled')
            if rel==Path('.') and str(pp).casefold()!=str(Path(self.get_project_folder())).casefold():
                unlink_btn.configure(command=lambda p=pp:self._unlink_project_source(p)); unlink_btn.pack(fill='x',padx=12,pady=(0,8))

        def open_selected(event=None):
            pp,root,iid=selected(event)
            if not pp:return 'break'
            try:is_dir=pp.is_dir()
            except Exception:is_dir=False
            if is_dir:
                ensure_loaded(iid)
                try:tr.item(iid,open=not bool(tr.item(iid,'open')))
                except Exception:pass
            else:self.open_external_path(pp)
            return 'break'

        def show_in_explorer():
            pp,_,_=selected()
            if not pp:return
            try:
                if os.name=='nt' and pp.is_file():subprocess.Popen(['explorer','/select,',str(pp)])
                else:self.open_external_path(pp if pp.is_dir() else pp.parent)
            except Exception as e:messagebox.showerror('Projekt-Explorer',str(e))
        def copy_path():
            pp,_,_=selected()
            if not pp:return
            try:self.clipboard_clear(); self.clipboard_append(str(pp)); self.update_idletasks()
            except Exception:pass

        categories=('Baugrund / Bodengutachten','Statik','Prüfstatik','Pläne / CAD','Wärmeschutz','Schallschutz','DGNB/QNG','Bauleitung','Kommunikation','Bescheinigungen','Dokumente','Fotos / Bilder','Sonstiges')
        def assign():
            pp,root,_=selected()
            if not pp or not root or pp==root:return
            w=tk.Toplevel(self); w.title('Fachlich zuordnen'); w.geometry('460x250'); w.configure(bg=BG); w.transient(self); w.grab_set()
            tk.Label(w,text='FACHLICHE ZUORDNUNG',bg=BG,fg=INK,font=('Segoe UI Semibold',13)).pack(anchor='w',padx=20,pady=(18,6)); tk.Label(w,text=pp.name,bg=BG,fg=MUTED,wraplength=410,justify='left').pack(anchor='w',padx=20,pady=(0,12))
            rel=pp.relative_to(root); v=tk.StringVar(value=effective_fast(rel)[0]); cb=ttk.Combobox(w,textvariable=v,state='readonly',values=categories,width=42); cb.pack(anchor='w',padx=20)
            def save():self._set_file_assignment(rel,pp.is_dir(),v.get()); w.destroy(); self.show_project_explorer()
            tk.Button(w,text='ZUORDNUNG SPEICHERN',command=save,bg=ACCENT,fg='white',bd=0,padx=14,pady=8).pack(anchor='e',padx=20,pady=18)

        def expand_all():
            # Nur bereits sichtbare Ebenen öffnen; weitere Ebenen laden asynchron beim jeweiligen Öffnen.
            for iid in list(pathmap):
                try:
                    pp=pathmap.get(iid)
                    if pp is not None and pp.is_dir():
                        tr.item(iid,open=True); ensure_loaded(iid)
                except Exception:pass
        def collapse_all():
            for iid in list(pathmap):
                try:tr.item(iid,open=False)
                except Exception:pass
        def refresh_tree():
            if search_var.get().strip():render_search_now()
            else:render_normal()
            refresh_detail()

        assign_btn.configure(command=assign); open_btn.configure(command=open_selected); explorer_btn.configure(command=show_in_explorer); copy_btn.configure(command=copy_path)
        tk.Button(toolbar,text='AKTUALISIEREN',command=refresh_tree,bg='#e7e4dc',fg=INK,bd=0,padx=10,pady=7).pack(side='right')
        tk.Button(toolbar,text='ZUKLAPPEN',command=collapse_all,bg='#e7e4dc',fg=INK,bd=0,padx=10,pady=7).pack(side='right',padx=6)
        tk.Button(toolbar,text='AUFKLAPPEN',command=expand_all,bg='#e7e4dc',fg=INK,bd=0,padx=10,pady=7).pack(side='right')
        menu=tk.Menu(self,tearoff=0)
        menu.add_command(label='Öffnen',command=open_selected); menu.add_command(label='Fachlich zuordnen…',command=assign); menu.add_command(label='Im Windows-Explorer zeigen',command=show_in_explorer); menu.add_separator(); menu.add_command(label='Pfad kopieren',command=copy_path)
        def popup(e):
            iid=tr.identify_row(e.y)
            if iid:
                tr.selection_set(iid); tr.focus(iid); menu.tk_popup(e.x_root,e.y_root)
        def on_tree_open(_evt=None):
            iid=tr.focus()
            try:self.after(1,lambda i=iid:ensure_loaded(i))
            except Exception:ensure_loaded(iid)
        tr.bind('<<TreeviewOpen>>',on_tree_open); tr.bind('<Double-1>',open_selected); tr.bind('<Return>',open_selected); tr.bind('<<TreeviewSelect>>',refresh_detail); tr.bind('<Button-3>',popup); tr.bind('<F5>',lambda e:refresh_tree()); tr.bind('<Control-c>',lambda e:(copy_path(),'break')[1])
        search_var.trace_add('write',render_search); search_entry.bind('<Escape>',lambda e:search_var.set(''))
        render_normal()
'''


def main():
    if not APP.exists():
        raise RuntimeError('1.5.1: app.py wurde nicht gefunden.')
    original=APP.read_text(encoding='utf-8')
    if f'APP_VERSION = "{VERSION_NEW}"' in original and MARKER in original:
        return 0
    if f'APP_VERSION = "{VERSION_OLD}"' not in original:
        raise RuntimeError('Update 1.5.1 erwartet Projektzentrale 1.5.0. Es wurde nichts verändert.')
    if 'PZ_PROJECT_EXPLORER_V1500' not in original:
        raise RuntimeError('1.5.1: Der Projekt-Explorer aus 1.5.0 wurde nicht gefunden. Es wurde nichts verändert.')
    candidate=_replace_method(original,'show_project_explorer',PROJECT_EXPLORER_METHOD)
    candidate=candidate.replace(f'APP_VERSION = "{VERSION_OLD}"',f'APP_VERSION = "{VERSION_NEW}"',1)
    for token in (MARKER,f'APP_VERSION = "{VERSION_NEW}"'):
        if token not in candidate:raise RuntimeError('1.5.1: Sicherheitsprüfung fehlgeschlagen: '+token)
    _compile_text(candidate,'app.py.1501.check')
    stamp=datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    backup=APP.with_name('app.py.vor_1_5_1_'+stamp+'.bak')
    shutil.copy2(APP,backup)
    tmp=APP.with_name('app.py.1501.tmp'); tmp.write_text(candidate,encoding='utf-8'); py_compile.compile(str(tmp),doraise=True); tmp.replace(APP)
    APP.with_name('patch_1501_report.txt').write_text('OK: Projektzentrale 1.5.1 installiert.\nProjekt-Explorer lädt Ordner jetzt asynchron.\nBackup: '+str(backup)+'\n',encoding='utf-8')
    return 0


if __name__=='__main__':
    try:
        raise SystemExit(main())
    except SystemExit:
        raise
    except Exception:
        import traceback
        APP.with_name('patch_1501_error.txt').write_text(traceback.format_exc(),encoding='utf-8')
        raise
