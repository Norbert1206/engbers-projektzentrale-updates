from pathlib import Path
import datetime
import py_compile
import shutil

APP = Path(__file__).resolve().parent / 'app.py'
VERSION_OLD = '1.5.1'
VERSION_NEW = '1.5.2'
MARKER_OLD = 'PZ_PROJECT_EXPLORER_ASYNC_V1501'
MARKER_NEW = 'PZ_PROJECT_EXPLORER_SAFE_V1502'


def _compile_text(text, name):
    p = APP.with_name(name)
    try:
        p.write_text(text, encoding='utf-8')
        py_compile.compile(str(p), doraise=True)
    finally:
        try: p.unlink()
        except Exception: pass


def _replace_between(source, start_token, end_token, replacement):
    a=source.find(start_token)
    if a<0: raise RuntimeError('1.5.2: Startmarke nicht gefunden: '+start_token.strip())
    b=source.find(end_token,a+len(start_token))
    if b<0: raise RuntimeError('1.5.2: Endmarke nicht gefunden: '+end_token.strip())
    return source[:a]+replacement+source[b:]


def main():
    if not APP.exists():
        raise RuntimeError('1.5.2: app.py wurde nicht gefunden.')
    original=APP.read_text(encoding='utf-8')
    if f'APP_VERSION = \"{VERSION_NEW}\"' in original and MARKER_NEW in original:
        return 0
    if f'APP_VERSION = \"{VERSION_OLD}\"' not in original:
        raise RuntimeError('Update 1.5.2 erwartet Projektzentrale 1.5.1. Es wurde nichts verändert.')
    if MARKER_OLD not in original:
        raise RuntimeError('1.5.2: Explorer aus 1.5.1 wurde nicht gefunden. Es wurde nichts verändert.')

    candidate=original.replace(MARKER_OLD,MARKER_NEW,1)

    load_start="        def ensure_loaded(iid):\n"
    load_end="        def add_source(src,open_root=False):\n"
    safe_load=r'''        def ensure_loaded(iid):
            # 1.5.2: KEINE Tkinter-Aufrufe aus Worker-Threads. Ordner werden kooperativ in kleinen Portionen gelesen.
            if not iid or iid in loaded or iid in loading:return
            pp=pathmap.get(iid); root=rootmap.get(iid)
            if pp is None or root is None:
                loaded.add(iid); return
            try:
                if not pp.is_dir():loaded.add(iid); return
            except Exception:
                loaded.add(iid); return
            loading.add(iid); token=generation[0]
            try:
                for child in tr.get_children(iid):
                    if tr.item(child,'text')==dummy:tr.item(child,text='Wird geladen …')
                load_info.configure(text='Ordner wird geladen …')
            except Exception:pass

            state={'it':None,'items':[],'error':''}
            try:
                import os as _os
                state['it']=_os.scandir(str(pp))
            except Exception as exc:
                state['error']=str(exc)

            def finish_scan():
                it=state.get('it')
                try:
                    if it is not None:it.close()
                except Exception:pass
                items=state.get('items') or []
                items.sort(key=lambda x:(not x['is_dir'],str(x['name']).casefold()))
                apply_loaded(iid,token,items,state.get('error') or '')

            def step_scan():
                if token!=generation[0]:
                    loading.discard(iid)
                    try:
                        if state.get('it') is not None:state['it'].close()
                    except Exception:pass
                    return
                if state.get('error') or state.get('it') is None:
                    finish_scan(); return
                try:
                    for _ in range(80):
                        try:entry=next(state['it'])
                        except StopIteration:
                            finish_scan(); return
                        try:is_dir=entry.is_dir(follow_symlinks=False)
                        except Exception:
                            try:is_dir=Path(entry.path).is_dir()
                            except Exception:is_dir=False
                        try:st=entry.stat(follow_symlinks=False); mt=st.st_mtime; sz=st.st_size
                        except Exception:mt=0; sz=0
                        state['items'].append({'path':entry.path,'name':entry.name,'is_dir':is_dir,'mtime':mt,'size':sz})
                    self.after(1,step_scan)
                except Exception as exc:
                    state['error']=str(exc); finish_scan()
            try:self.after_idle(step_scan)
            except Exception:finish_scan()

'''
    candidate=_replace_between(candidate,load_start,load_end,safe_load)

    search_start="        def render_search_now():\n"
    search_end="        def render_search(*_):\n"
    safe_search=r'''        def render_search_now():
            # 1.5.2: projektweite Suche kooperativ über Tk-after, ohne Hintergrundthread.
            q=search_var.get().strip().casefold()
            if not q:render_normal(); return
            generation[0]+=1; token=generation[0]; loaded.clear(); loading.clear()
            for iid in tr.get_children(''):tr.delete(iid)
            pathmap.clear(); rootmap.clear(); sourcemap.clear()
            load_info.configure(text='Projekt wird durchsucht …')
            hits=[]; total=[0]; source_index=[0]; current={'src':None,'root':None,'walk':None}

            def next_source():
                while source_index[0] < len(sources):
                    src=sources[source_index[0]]; source_index[0]+=1
                    root=Path(src['path'])
                    if not root.exists():continue
                    try:
                        current['src']=src; current['root']=root; current['walk']=os.walk(str(root))
                        return True
                    except Exception:continue
                current['walk']=None; return False

            def finish_search():
                if token!=generation[0]:return
                groups={}
                for src,info in hits:
                    key=(str(src.get('kind','')),str(src.get('label','')),str(src.get('path','')))
                    groups.setdefault(key,[src,[]])[1].append(info)
                try:
                    for _key,(src,items) in groups.items():
                        root=Path(src['path']); label=f"{src['kind']}: {src['label']}"
                        parent=tr.insert('','end',text=label,values=('Speicherort','—','—','Projekt',str(root)),open=True)
                        pathmap[parent]=root; rootmap[parent]=root; sourcemap[parent]=src; loaded.add(parent)
                        items.sort(key=lambda x:(not x['is_dir'],str(x['path']).casefold()))
                        for info in items:insert_child(parent,root,info,src)
                    load_info.configure(text=(f'{total[0]} Treffer' if total[0]<600 else '600 Treffer · Suche begrenzt'))
                except Exception:pass

            def step_search():
                if token!=generation[0]:return
                processed_dirs=0
                try:
                    while processed_dirs<12 and total[0]<600:
                        if current['walk'] is None:
                            if not next_source():finish_search(); return
                        try:base,dirs,files=next(current['walk'])
                        except StopIteration:
                            current['walk']=None; continue
                        except Exception:
                            current['walk']=None; continue
                        processed_dirs+=1
                        try:dirs[:]=[d for d in dirs if not Path(base,d).is_symlink()]
                        except Exception:pass
                        src=current['src']; root=current['root']
                        for name,is_dir in [(d,True) for d in dirs]+[(f,False) for f in files]:
                            if total[0]>=600:break
                            pp=Path(base)/name
                            try:rel=pp.relative_to(root)
                            except Exception:rel=Path(name)
                            if q not in (name+' '+str(rel)).casefold():continue
                            try:st=pp.stat(); mt=st.st_mtime; sz=st.st_size
                            except Exception:mt=0; sz=0
                            hits.append((src,{'path':str(pp),'name':name,'is_dir':is_dir,'mtime':mt,'size':sz})); total[0]+=1
                    if total[0]>=600:finish_search(); return
                    self.after(1,step_search)
                except Exception:
                    finish_search()
            try:self.after_idle(step_search)
            except Exception:finish_search()

'''
    candidate=_replace_between(candidate,search_start,search_end,safe_search)

    open_start="        def open_selected(event=None):\n"
    open_end="        def show_in_explorer():\n"
    safe_open=r'''        def open_selected(event=None):
            # 1.5.2: Öffnen vollständig abgefangen; Fehler werden protokolliert statt die Oberfläche zu beenden.
            pp,root,iid=selected(event)
            if not pp:return 'break'
            try:
                is_dir=pp.is_dir()
                if is_dir:
                    ensure_loaded(iid)
                    try:tr.item(iid,open=not bool(tr.item(iid,'open')))
                    except Exception:pass
                else:
                    ok=self.open_external_path(str(pp))
                    if ok is False:return 'break'
            except Exception as exc:
                try:
                    import traceback
                    APP_ERR=Path(__file__).resolve().parent/'project_explorer_error.txt'
                    APP_ERR.write_text(datetime.datetime.now().isoformat()+'\\n'+traceback.format_exc(),encoding='utf-8')
                except Exception:pass
                try:messagebox.showerror('Projekt-Explorer',f'Datei konnte nicht geöffnet werden:\\n{exc}')
                except Exception:pass
            return 'break'

'''
    candidate=_replace_between(candidate,open_start,open_end,safe_open)

    candidate=candidate.replace(f'APP_VERSION = \"{VERSION_OLD}\"',f'APP_VERSION = \"{VERSION_NEW}\"',1)
    for token in (MARKER_NEW,f'APP_VERSION = \"{VERSION_NEW}\"','KEINE Tkinter-Aufrufe aus Worker-Threads'):
        if token not in candidate:raise RuntimeError('1.5.2: Sicherheitsprüfung fehlgeschlagen: '+token)
    if "threading.Thread(target=worker,name='PZ-Explorer" in candidate:
        raise RuntimeError('1.5.2: Unsicherer Explorer-Worker wurde nicht vollständig entfernt.')
    _compile_text(candidate,'app.py.1502.check')
    stamp=datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    backup=APP.with_name('app.py.vor_1_5_2_'+stamp+'.bak')
    shutil.copy2(APP,backup)
    tmp=APP.with_name('app.py.1502.tmp'); tmp.write_text(candidate,encoding='utf-8'); py_compile.compile(str(tmp),doraise=True); tmp.replace(APP)
    APP.with_name('patch_1502_report.txt').write_text('OK: Projektzentrale 1.5.2 installiert.\\nProjekt-Explorer ohne Tkinter-Workerthreads; Dateiöffnen abgesichert.\\nBackup: '+str(backup)+'\\n',encoding='utf-8')
    return 0


if __name__=='__main__':
    try:
        raise SystemExit(main())
    except SystemExit:
        raise
    except Exception:
        import traceback
        try:APP.with_name('patch_1502_error.txt').write_text(traceback.format_exc(),encoding='utf-8')
        except Exception:pass
        raise
