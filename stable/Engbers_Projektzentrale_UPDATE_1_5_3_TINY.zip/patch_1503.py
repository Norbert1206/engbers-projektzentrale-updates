from pathlib import Path
import datetime
import py_compile
import shutil
import traceback

APP = Path(__file__).resolve().parent / 'app.py'
VERSION_OLD = '1.5.1'
VERSION_NEW = '1.5.3'
OLD_MARKER = 'PZ_PROJECT_EXPLORER_ASYNC_V1501'
NEW_MARKER = 'PZ_PROJECT_EXPLORER_SAFE_V1503'

THREAD_LOAD = '''            try:\n                import threading\n                threading.Thread(target=worker,name='PZ-Explorer-Load',daemon=True).start()\n            except Exception:\n                worker()'''
THREAD_SEARCH = '''            try:\n                import threading\n                threading.Thread(target=worker,name='PZ-Explorer-Search',daemon=True).start()\n            except Exception:worker()'''
SAFE_LOAD = '''            # 1.5.3: kein Tkinter-Zugriff aus Worker-Threads.\n            # Der Verzeichnis-Scan startet über die normale Tk-Ereignisschleife.\n            try:self.after(1,worker)\n            except Exception:worker()'''
SAFE_SEARCH = '''            # 1.5.3: Suche ebenfalls ohne Tkinter-Worker-Thread.\n            try:self.after(1,worker)\n            except Exception:worker()'''


def main():
    if not APP.exists():
        raise RuntimeError('1.5.3: app.py wurde nicht gefunden.')
    original = APP.read_text(encoding='utf-8')

    if f'APP_VERSION = "{VERSION_NEW}"' in original and NEW_MARKER in original:
        return 0
    if f'APP_VERSION = "{VERSION_OLD}"' not in original:
        raise RuntimeError('Update 1.5.3 erwartet Projektzentrale 1.5.1. Es wurde nichts verändert.')
    if OLD_MARKER not in original:
        raise RuntimeError('1.5.3: Projekt-Explorer aus 1.5.1 wurde nicht gefunden. Es wurde nichts verändert.')
    if THREAD_LOAD not in original or THREAD_SEARCH not in original:
        raise RuntimeError('1.5.3: Die erwarteten Thread-Blöcke wurden nicht gefunden. Es wurde nichts verändert.')

    candidate = original.replace(THREAD_LOAD, SAFE_LOAD, 1)
    candidate = candidate.replace(THREAD_SEARCH, SAFE_SEARCH, 1)
    candidate = candidate.replace(OLD_MARKER, NEW_MARKER, 1)
    candidate = candidate.replace(f'APP_VERSION = "{VERSION_OLD}"', f'APP_VERSION = "{VERSION_NEW}"', 1)

    # Sichtbare alte Versionsangabe aus dem 1.5.0-Cockpit mitziehen, sofern vorhanden.
    candidate = candidate.replace('Projektzentrale 1.5.0', 'Projektzentrale 1.5.3')

    check = APP.with_name('app.py.1503.check')
    try:
        check.write_text(candidate, encoding='utf-8')
        py_compile.compile(str(check), doraise=True)
    finally:
        try: check.unlink()
        except Exception: pass

    stamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    backup = APP.with_name('app.py.vor_1_5_3_' + stamp + '.bak')
    shutil.copy2(APP, backup)
    tmp = APP.with_name('app.py.1503.tmp')
    tmp.write_text(candidate, encoding='utf-8')
    py_compile.compile(str(tmp), doraise=True)
    tmp.replace(APP)

    APP.with_name('patch_1503_report.txt').write_text(
        'OK: Projektzentrale 1.5.3 installiert.\n'
        'Projekt-Explorer: keine Tkinter-Aufrufe mehr aus Hintergrundthreads.\n'
        'Startmechanismus: unsichtbarer Launcher vorbereitet.\n'
        'Backup: ' + str(backup) + '\n',
        encoding='utf-8')
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except SystemExit:
        raise
    except Exception:
        APP.with_name('patch_1503_error.txt').write_text(traceback.format_exc(), encoding='utf-8')
        raise
