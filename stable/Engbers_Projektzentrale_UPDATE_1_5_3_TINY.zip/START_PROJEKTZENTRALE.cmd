@echo off
cd /d "%~dp0"
start "" /b wscript.exe //B "%~dp0pz_launcher.vbs"
exit /b 0
